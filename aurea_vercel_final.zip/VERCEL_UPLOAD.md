# Áurea — Vercel

## IMPORTANTE
Subí **el contenido de esta carpeta**, no una carpeta adicional dentro de otra.
En GitHub, `package.json`, `index.html`, `src/`, `api/` y `vercel.json` deben quedar en la raíz del repositorio.

En Vercel:
- Framework Preset: Vite
- Root Directory: `.` (si los archivos están en la raíz)
- Build Command: `npm run build`
- Output Directory: `dist`

Variable de entorno necesaria para IA:
- `GEMINI_API_KEY` = tu clave de Gemini

No uses `VITE_GEMINI_API_KEY` para la clave secreta.

Si el repositorio contiene una carpeta `aurea_vercel_final` y dentro están estos archivos, entonces Root Directory debe ser `aurea_vercel_final`.
