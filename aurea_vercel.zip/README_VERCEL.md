# Áurea — despliegue en Vercel

1. Sube este proyecto a un repositorio GitHub/GitLab/Bitbucket.
2. En Vercel selecciona **Add New Project** y conecta el repositorio.
3. Vercel detectará Vite. El build es `npm run build` y la salida es `dist`.
4. En **Settings → Environment Variables** crea `GEMINI_API_KEY` con la clave real de Gemini. No uses `VITE_GEMINI_API_KEY`.
5. Haz un nuevo Deploy.

Las rutas `/api/ai/*` y `/api/security/scan-file` son funciones serverless de Vercel. `server.ts` se conserva para desarrollo local, pero Vercel no necesita ejecutarlo.

Importante: el rate limit incluido en las funciones es una protección básica por instancia. Para producción con tráfico alto conviene usar un rate limiter externo (por ejemplo Redis/Upstash) y una autenticación real en servidor.
