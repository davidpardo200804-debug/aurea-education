import type { VercelRequest, VercelResponse } from '@vercel/node';
import { limit, method, sameOrigin, setSecurityHeaders, validText } from '../_utils.js';

export default function handler(req: VercelRequest, res: VercelResponse) {
  setSecurityHeaders(res);
  if (!method(req, res) || !sameOrigin(req)) return res.status(403).json({ error: 'Origen no permitido.' });
  if (!limit(req, res, 30)) return;
  const { fileName, fileSize, mimeType } = req.body || {};
  if (!validText(fileName, 255) || typeof fileSize !== 'number' || !Number.isSafeInteger(fileSize) || fileSize < 0 || fileSize > 25 * 1024 * 1024 || (mimeType !== undefined && typeof mimeType !== 'string')) {
    return res.status(400).json({ safe: false, threat: 'Datos de archivo inválidos.' });
  }
  const ext = fileName.split('.').pop()?.toLowerCase() || '';
  const blocked = ['exe', 'bat', 'cmd', 'sh', 'vbs', 'msi', 'scr', 'php', 'apk', 'bin', 'dll'];
  if (blocked.includes(ext)) return res.json({ safe: false, threat: `Extensión .${ext} no permitida por políticas de Áurea Shield.` });
  return res.json({ safe: true, message: 'Archivo aceptado por reglas de tipo y tamaño. Esto no constituye un análisis antivirus completo.' });
}
