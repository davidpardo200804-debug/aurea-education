import type { VercelRequest, VercelResponse } from '@vercel/node';
import { GoogleGenAI } from '@google/genai';
import { cleanForPrompt, limit, method, sameOrigin, setSecurityHeaders, validText } from '../_utils.js';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  setSecurityHeaders(res);
  if (!method(req, res) || !sameOrigin(req)) return res.status(403).json({ error: 'Origen no permitido.' });
  if (!limit(req, res, 20)) return;
  try {
    const { message, context, contactName, contactType } = req.body || {};
    if (!validText(message, 4000)) return res.status(400).json({ error: 'Mensaje inválido.' });
    if (context !== undefined && typeof context !== 'string') return res.status(400).json({ error: 'Contexto inválido.' });
    if (contactName !== undefined && typeof contactName !== 'string') return res.status(400).json({ error: 'Nombre inválido.' });
    if (contactType !== undefined && typeof contactType !== 'string') return res.status(400).json({ error: 'Tipo de contacto inválido.' });

    const safeMessage = cleanForPrompt(message, 4000);
    const safeContext = typeof context === 'string' ? cleanForPrompt(context, 6000) : '';
    const safeContactName = typeof contactName === 'string' ? cleanForPrompt(contactName, 120) : 'Aspirante';
    const safeContactType = typeof contactType === 'string' ? cleanForPrompt(contactType, 80) : 'interesado';
    const apiKey = process.env.GEMINI_API_KEY;

    if (!apiKey) return res.status(503).json({ error: 'El servicio de IA no está configurado.' });

    const institutionInfo = `Institución: Academia de Belleza Arte & Estilo. Programas: Peluquería Integral & Estilismo (12 meses, $2.400.000 COP); Barbería Profesional (6 meses, $2.100.000 COP); Manicura Rusa, Polygel & Nail Art (4 meses, $1.900.000 COP); Colorimetría Avanzada & Balayage. Horarios: lunes-jueves 8:00-12:00, 14:00-18:00 y sábados 8:00-14:00. Abono inicial desde $300.000 COP. Medios de pago: efectivo, Nequi, Daviplata, PSE y tarjetas. WhatsApp oficial: +57 310 456 7890.`;
    const systemInstruction = `Eres la asistente virtual experta de admisiones de la Academia de Belleza Arte & Estilo. Responde en español, con tono profesional y cálido, de forma concisa. No inventes precios, cupos, horarios ni políticas. ${institutionInfo}`;
    const prompt = `El usuario (${safeContactName}, tipo: ${safeContactType}) envió: "${safeMessage}"\n${safeContext ? `Historial reciente:\n${safeContext}\n` : ''}Redacta una respuesta lista para WhatsApp:`;

    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({ model: 'gemini-3.8-flash', contents: prompt, config: { systemInstruction, temperature: 0.7 } });
    return res.status(200).json({ reply: response.text || 'No fue posible generar una respuesta.' });
  } catch (error) {
    console.error('WhatsApp AI error', error instanceof Error ? error.message : 'unknown');
    return res.status(502).json({ error: 'No fue posible procesar la solicitud de IA.' });
  }
}
