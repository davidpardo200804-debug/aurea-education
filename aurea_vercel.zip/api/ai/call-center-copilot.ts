import type { VercelRequest, VercelResponse } from '@vercel/node';
import { GoogleGenAI } from '@google/genai';
import { cleanForPrompt, limit, method, sameOrigin, setSecurityHeaders, validText } from '../_utils.js';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  setSecurityHeaders(res);
  if (!method(req, res) || !sameOrigin(req)) return res.status(403).json({ error: 'Origen no permitido.' });
  if (!limit(req, res, 20)) return;
  try {
    const { query, agentName, currentGroupsInfo, context } = req.body || {};
    if (!validText(query, 4000)) return res.status(400).json({ error: 'Consulta inválida.' });
    if (agentName !== undefined && typeof agentName !== 'string') return res.status(400).json({ error: 'Nombre inválido.' });
    if (context !== undefined && typeof context !== 'string') return res.status(400).json({ error: 'Contexto inválido.' });
    const safeQuery = cleanForPrompt(query, 4000);
    const safeAgentName = typeof agentName === 'string' ? cleanForPrompt(agentName, 120) : 'Asesora';
    const safeContext = typeof context === 'string' ? cleanForPrompt(context, 5000) : '';
    const safeGroups = currentGroupsInfo && typeof currentGroupsInfo === 'object' ? JSON.stringify(currentGroupsInfo).slice(0, 10000) : '';
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) return res.status(503).json({ error: 'El servicio de IA no está configurado.' });

    const knowledge = `Academia de Belleza Arte & Estilo. Peluquería Integral: máximo 25, mínimo 12, $2.400.000 COP, mañana/tarde. Barbería: máximo 20, mínimo 10, $2.100.000 COP, tarde/sábados. Manicura Rusa & Polygel: máximo 18, mínimo 8, $1.900.000 COP, sábados. Comisiones: $50.000 COP por matrícula y bonos según políticas internas. Las asesoras no pueden conceder descuentos sin autorización administrativa.`;
    const systemInstruction = `Eres Co-Pilot IA interno para asesoras de admisiones. Da información precisa, evita inventar datos y distingue información en vivo de reglas generales. Apoya manejo de objeciones y procesos comerciales sin prometer condiciones no autorizadas. ${knowledge}${safeGroups ? `\nGrupos actuales:\n${safeGroups}` : ''}${safeContext ? `\nContexto:\n${safeContext}` : ''}`;
    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({ model: 'gemini-3.8-flash', contents: `Asesora ${safeAgentName}: ${safeQuery}`, config: { systemInstruction, temperature: 0.7 } });
    return res.status(200).json({ reply: response.text || 'No fue posible generar una respuesta.' });
  } catch (error) {
    console.error('Call center AI error', error instanceof Error ? error.message : 'unknown');
    return res.status(502).json({ error: 'No fue posible procesar la solicitud de IA.' });
  }
}
