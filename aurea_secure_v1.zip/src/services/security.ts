// Client-side security helpers. These controls reduce accidental exposure and abuse,
// but they are NOT a replacement for server-side authentication/authorization.

export interface SecurityScanResult {
  isSafe: boolean;
  threatDetected?: string;
  fileDetails?: { name: string; size: number; mimeType: string; hash: string };
}

export interface SecurityAuditLog {
  id: string;
  timestamp: string;
  ip: string;
  event: 'login_success' | 'login_failed' | 'file_scanned' | 'threat_blocked' | 'sanitization_triggered' | 'rate_limit_activated';
  severity: 'info' | 'warning' | 'critical';
  details: string;
}

const DANGEROUS_EXTENSIONS = new Set([
  'exe','bat','cmd','sh','bash','vbs','vbe','js','jse','wsf','wsh','scr','pif','com','hta','cpl','msc','jar','apk','msi','bin','dll','sys','php','asp','aspx','jsp','cgi','pl','pyw','ps1','psm1'
]);

const MALICIOUS_PATTERNS = [
  /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,
  /javascript\s*:/gi,
  /\bon(?:load|error|click|mouseover|focus|submit)\s*=/gi,
  /<\s*(iframe|object|embed|svg)\b/gi,
  /\bunion\s+select\b/gi,
  /(?:^|\s)--\s*(?:$|\S)/gm,
  /;\s*drop\s+table\b/gi,
  /(?:__proto__|prototype\s*\[|constructor\s*\[)/gi,
];

function escapeHtml(value: string): string {
  return value.replace(/[&<>"']/g, (c) => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#x27;' }[c]!));
}

class CyberShieldService {
  private failedAttempts = 0;
  private lockoutUntil = 0;
  private auditLogs: SecurityAuditLog[] = [];

  constructor() {
    this.auditLogs = [];
  }

  // Use this only when text is going into an HTML context. React JSX already escapes text nodes.
  sanitizeInput(input: string): string {
    if (typeof input !== 'string') return '';
    const threatFound = MALICIOUS_PATTERNS.some((pattern) => {
      pattern.lastIndex = 0;
      return pattern.test(input);
    });
    if (threatFound) {
      this.logEvent({ event: 'sanitization_triggered', severity: 'warning', details: 'Entrada con patrones de inyección detectada.' });
    }
    return escapeHtml(input);
  }

  async scanFile(file: File): Promise<SecurityScanResult> {
    const name = file.name.trim();
    const extension = name.includes('.') ? name.split('.').pop()!.toLowerCase() : '';
    if (DANGEROUS_EXTENSIONS.has(extension)) {
      this.logEvent({ event: 'threat_blocked', severity: 'critical', details: `Archivo bloqueado por extensión no permitida (.${extension}).` });
      return { isSafe: false, threatDetected: `El tipo de archivo .${extension} no está permitido.` };
    }
    if (file.size > 25 * 1024 * 1024) {
      return { isSafe: false, threatDetected: 'El archivo supera el límite de 25 MB.' };
    }

    const buffer = await file.arrayBuffer();
    const digest = await crypto.subtle.digest('SHA-256', buffer);
    const hash = Array.from(new Uint8Array(digest)).map((b) => b.toString(16).padStart(2, '0')).join('');
    this.logEvent({ event: 'file_scanned', severity: 'info', details: `Archivo "${name}" validado por extensión, tamaño y SHA-256.` });
    return { isSafe: true, fileDetails: { name, size: file.size, mimeType: file.type || 'application/octet-stream', hash } };
  }

  recordFailedLogin(): { isLocked: boolean; remainingSeconds: number } {
    this.failedAttempts += 1;
    if (this.failedAttempts >= 5) {
      this.lockoutUntil = Date.now() + 60_000;
      this.logEvent({ event: 'rate_limit_activated', severity: 'warning', details: 'Bloqueo local temporal tras varios intentos fallidos.' });
      return { isLocked: true, remainingSeconds: 60 };
    }
    this.logEvent({ event: 'login_failed', severity: 'warning', details: `Credenciales inválidas (intento ${this.failedAttempts}/5).` });
    return { isLocked: false, remainingSeconds: 0 };
  }

  resetLoginAttempts() { this.failedAttempts = 0; this.lockoutUntil = 0; }

  isLoginLocked() {
    const remainingSeconds = Math.max(0, Math.ceil((this.lockoutUntil - Date.now()) / 1000));
    if (!remainingSeconds) this.lockoutUntil = 0;
    return { isLocked: remainingSeconds > 0, remainingSeconds };
  }

  logEvent(log: Omit<SecurityAuditLog, 'id' | 'timestamp' | 'ip'>) {
    this.auditLogs.unshift({ id: `sec-${crypto.randomUUID?.() || Date.now()}`, timestamp: new Date().toISOString(), ip: 'no disponible en navegador', ...log });
    this.auditLogs = this.auditLogs.slice(0, 50);
  }

  getAuditLogs() { return [...this.auditLogs]; }
}

export const cyberShield = new CyberShieldService();
