import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  X,
  Lock,
  AlertCircle,
  User,
  Scissors,
} from 'lucide-react';
import { appStorage } from '../services/storage';
import { cyberShield } from '../services/security';
import { UserRole } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const { setCurrentUser, playSuccessSound } = useApp();
  const [usernameOrEmail, setUsernameOrEmail] = useState('');
  const [password, setPassword] = useState('');
  const [selectedRole, setSelectedRole] = useState<UserRole>('admin');
  const [error, setError] = useState('');
  const [lockMessage, setLockMessage] = useState('');

  if (!isOpen) return null;

  const users = appStorage.getStore().users;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLockMessage('');
    const lock = cyberShield.isLoginLocked();
    if (lock.isLocked) {
      setLockMessage(`Demasiados intentos. Espera ${lock.remainingSeconds} segundos antes de volver a intentarlo.`);
      return;
    }

    const inputLower = usernameOrEmail.trim().toLowerCase();

    // Find user matching email, documentId, or name/username prefix
    const found = users.find(
      (u) =>
        u.email.toLowerCase() === inputLower ||
        u.documentId?.toLowerCase() === inputLower ||
        u.name.toLowerCase() === inputLower
    );

    if (!found || !found.active) {
      cyberShield.recordFailedLogin();
      setError('Credenciales no válidas.');
      return;
    }

    // Check password (supports custom pass or standard 123/123456)
    const validPassword = typeof found.password === 'string' && found.password === password;

    if (!validPassword) {
      const result = cyberShield.recordFailedLogin();
      setError(result.isLocked ? 'Demasiados intentos. Acceso temporalmente bloqueado.' : 'Credenciales no válidas.');
      return;
    }

    // Enforce matching role as requested by user ("deban poner usuario - contraseña y rol")
    if (found.role !== selectedRole) {
      const roleNames: Record<UserRole, string> = {
        admin: 'Administración / Directora Académica / Coordinación',
        teacher: 'Docente / Instructor',
        student: 'Estudiante / Aprendiz',
        agent: 'Asesora de Call Center & Matrículas',
      };
      setError(
        `El usuario ingresado (${found.name}) está registrado con el rol de "${roleNames[found.role]}", pero seleccionaste "${roleNames[selectedRole]}". Por favor selecciona el rol correcto en la lista desplegable.`
      );
      return;
    }

    // Success login
    cyberShield.resetLoginAttempts();
    setCurrentUser(found);
    playSuccessSound();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#0b132b] border border-sky-500/30 rounded-3xl shadow-2xl p-6 sm:p-8 overflow-hidden max-h-[92vh] overflow-y-auto text-white">
        {/* Glow decoration */}
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 rounded-full bg-sky-500/15 blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -ml-16 -mb-16 w-64 h-64 rounded-full bg-purple-600/15 blur-3xl pointer-events-none" />

        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header with Official Logo & Branding */}
        <div className="text-center mb-6 relative z-10">
          <div className="w-20 h-20 mx-auto rounded-3xl bg-white p-1.5 shadow-xl shadow-sky-500/25 border-2 border-sky-400/40 flex items-center justify-center mb-3">
            <img
              src="/logo.jpg"
              alt="Arte & Estilo"
              className="w-full h-full object-contain rounded-2xl"
              onError={(e) => {
                (e.target as HTMLElement).style.display = 'none';
              }}
            />
          </div>
          <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-sky-500/20 text-sky-300 border border-sky-500/30 text-[10px] font-bold tracking-wider uppercase mb-1">
            <Scissors className="w-3 h-3 text-purple-300" />
            <span>Academia de Belleza</span>
          </div>
          <h2 className="text-2xl font-black text-white tracking-tight">Arte & Estilo</h2>
          <p className="text-xs text-slate-300 mt-1 max-w-sm mx-auto">
            Ingreso al Sistema Institucional: ingresa tu usuario, contraseña y rol asignado.
          </p>
        </div>

        {lockMessage && (
          <div className="mb-4 p-3.5 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-200 text-xs">{lockMessage}</div>
        )}

        {error && (
          <div className="mb-4 p-3.5 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-200 text-xs flex items-start space-x-2.5">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
            <span className="leading-relaxed">{error}</span>
          </div>
        )}

        {/* Credentials Form: Usuario + Contraseña + Rol */}
        <form onSubmit={handleLogin} className="space-y-3.5 relative z-10">
          {/* 1. Usuario */}
          <div>
            <label className="block text-xs font-semibold text-sky-200 mb-1">
              Usuario, Documento o Correo Electrónico *
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-sky-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                required
                value={usernameOrEmail}
                onChange={(e) => setUsernameOrEmail(e.target.value)}
                placeholder="ej: carlos.mendoza@arteyestilo.edu.co o CC"
                className="w-full bg-slate-900/90 border border-slate-700 rounded-xl pl-10 pr-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-sky-400"
              />
            </div>
          </div>

          {/* 2. Contraseña */}
          <div>
            <label className="block text-xs font-semibold text-sky-200 mb-1">Contraseña *</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-sky-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Ingresa tu contraseña"
                className="w-full bg-slate-900/90 border border-slate-700 rounded-xl pl-10 pr-3.5 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-sky-400"
              />
            </div>
          </div>

          {/* 3. Rol Institucional */}
          <div>
            <label className="block text-xs font-semibold text-purple-200 mb-1">Rol Institucional *</label>
            <div className="relative">
              <Shield className="w-4 h-4 text-purple-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <select
                value={selectedRole}
                onChange={(e) => setSelectedRole(e.target.value as UserRole)}
                className="w-full bg-slate-900/90 border border-slate-700 rounded-xl pl-10 pr-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-purple-400 font-medium"
              >
                <option value="admin">Administrador / Directora Académica / Coordinador</option>
                <option value="agent">Asesora de Call Center & Admisiones</option>
                <option value="teacher">Profesor / Instructor de Belleza</option>
                <option value="student">Estudiante / Aprendiz</option>
              </select>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-sky-500 via-blue-600 to-purple-600 hover:from-sky-400 hover:to-purple-500 font-bold text-xs text-white shadow-lg shadow-sky-500/25 transition-all cursor-pointer mt-2 active:scale-98"
          >
            Iniciar Sesión en Arte & Estilo
          </button>
        </form>

      </div>
    </div>
  );
};
