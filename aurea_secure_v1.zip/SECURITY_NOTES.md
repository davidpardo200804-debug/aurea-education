# Notas de seguridad de Áurea

Esta versión endurece varios riesgos del proyecto, pero hay una limitación estructural importante: la aplicación todavía guarda su base de datos y su autenticación principal en el navegador (`localStorage`/código cliente). Eso no puede considerarse un límite de seguridad frente a un usuario malicioso con control del navegador.

Para producción, la autenticación, autorización, datos académicos/financieros y auditoría deben migrarse a un backend con base de datos y sesiones seguras.
